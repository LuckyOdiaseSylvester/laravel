@extends('layouts.admin')
@section('content')
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <h1>hhhokdjdjhidudujdidi</h1>

          </div>
          <!-- content-wrapper ends -->
          @endsection