
<?php $__env->startSection('content'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class=" content-wrapper">

            <?php if(Session::has('add')): ?>
              <div class="alert alert-success text-center" role="alert">
                <?php echo e(Session::get('add')); ?>

              </div>
              <?php endif; ?>
              <?php if(Session::has('delete')): ?>
              <div class="alert alert-danger text-center" role="alert">
                <?php echo e(Session::get('delete')); ?>

              </div>
              <?php endif; ?>

              <?php if(Session::has('edit')): ?>
              <div class="alert alert-success text-center" role="alert">
                <?php echo e(Session::get('edit')); ?>

              </div>
              <?php endif; ?>


            <h1 class="text-center">All Products</h1>
            <div class="table-responsive">

          <table class="table table-bordered ">
            <tr>
              <th>S/N </th>
              <th>Title </th>
              <th> Description  </th>
              <th> Price </th>
              <th>Discount  </th>
              <th> Quantity </th>
              <th> Category </th>
              <th> Image </th>
              <th class="text-center">Action </th>
            </tr>
            <style>
             
            </style>
                              

            <?php
                $i=1;
            ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($i++); ?></td>  
                  <td><?php echo e($product->title); ?></td> 
                  <td style="white-space: pre-wrap; word-wrap: break-word;width:100px"><?php echo e($product->description); ?></td>  
                  <td>$<?php echo e($product->price); ?></td>  
                  <?php if($product->discount==null): ?>
                  <td> NULL</td>
                  <?php else: ?>
                  <td>$<?php echo e($product->discount); ?></td>
                  <?php endif; ?>
                  <td><?php echo e($product->quantity); ?></td>  
                  <td><?php echo e($product->category); ?></td> 
                  <td class="">
                    <img src="/product/<?php echo e($product->image); ?>" alt="<?php echo e($product->image); ?>">
                    
          
                  </td>
                  <td>
                    <a href="<?php echo e(route('edit-product',$product->id)); ?>" class="btn btn-success mx-2">Edit</a>
                    <a href="<?php echo e(route('view',$product->id)); ?>" class="btn btn-warning mx-2">View</a>
                    <a href="<?php echo e(route('delete_pro',$product->id)); ?>" class="btn btn-danger">Delete</a>

                  </td>
            

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          </table>
        </div>


          </div>
          <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopping_site\resources\views/show_product.blade.php ENDPATH**/ ?>