
<base href="/public">
<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-center flex-column align-items-center">
  <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <h1 class="mt-5 mb-5"> <?php echo e('This product has already been added to your cart'); ?></h1> 
<p class="my-5"><a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Back to home</a></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopping_site\resources\views/added_already.blade.php ENDPATH**/ ?>