
<base href="/public">
<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-center mb-2">
    <div class="card" style="width: 18rem;">

      <img src="/product/<?php echo e($products->image); ?>" alt="<?php echo e($products->image); ?>">
      <div class="card-body">
            <?php if($products->discount==!null): ?>
          <div class="card-text"><Span class=" h5 pr-2">Title:</Span><?php echo e($products->title); ?></div>
          <div class="card-text"><span class="h5 pr-2">Category:</span><?php echo e($products->category); ?></div>
          <div class="card-text"><span class="h5 pr-2">Description:</span><?php echo e($products->description); ?></div>
          <div class="card-text text-primary"><span class="h5 pr-2">Price:</span style="text-decoration: line-through">$<?php echo e($products->price); ?></div>
          <div class="card-text text-danger"><span class="h5  pr-2">Discount Price:</span ><span 
             >NGN <?php echo e($products->discount); ?></span></div>
            <?php else: ?>
            <h5 class="card-title"><Span class="pr-2">Title:</Span><?php echo e($products->title); ?></h5>
          <div class="card-text"><span class="h5 pr-2">Category:</span><?php echo e($products->category); ?></div>
          <div class="card-text"><span class="h5 pr-2">Description:</span><?php echo e($products->description); ?></div>
          <div class="card-text text-primary"><span class="h5 pr-2">Price:</span>NGN <?php echo e($products->price); ?></div>
      
            <?php endif; ?>
          </div>
      </div>

</div>
<div class="but container d-flex justify-content-center mb-2">
  <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Back to home</a>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopping_site\resources\views/product_details.blade.php ENDPATH**/ ?>