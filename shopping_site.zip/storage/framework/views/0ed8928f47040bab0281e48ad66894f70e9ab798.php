<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container d-flex flex-column justify-content-center align-items-center">


    <h1 class="">Payment Form</h1>
    <form method="POST" action="<?php echo e(route('pay')); ?>" accept-charset="UTF-8" class="form-horizontal" role="form">
       <?php echo csrf_field(); ?>
        <div class="row" style="margin-bottom:40px;">
            <div class="col-md-8 col-md-offset-2">
                <p>
                    <div>
                       
                        <span  class="text-center"><?php echo e(Auth::user()->name); ?>, you are about to make payment of</span>
                        <span>NGN<?php echo e(number_format( $total_price)); ?></span>
                    </div>
                </p>
                <input type="hidden" name="email" value="<?php echo e(Auth::user()->email); ?>"> 
                <input type="hidden" name="orderID" value="345">
                <input type="hidden" name="amount" value="<?php echo e($total_price*100); ?>"> 
                <input type="hidden" name="quantity" value="1"> 
                <input type="hidden" name="currency" value="NGN">
                <input type="hidden" name="metadata" value="<?php echo e(json_encode($array = ['key_name' => 'value',])); ?>" > 
                <input type="hidden" name="reference" value="<?php echo e(Paystack::genTranxRef()); ?>"> 
                
                
                
                <?php echo e(csrf_field()); ?> 
    
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
    
                <p>
                    <button class="btn btn-success btn-lg btn-block" type="submit" value="Pay Now!">
                        <i class="fa fa-plus-circle fa-lg"></i> Pay Now!
                    </button>
                </p>
            </div>
        </div>
    </form>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\shopping_site\resources\views/form.blade.php ENDPATH**/ ?>