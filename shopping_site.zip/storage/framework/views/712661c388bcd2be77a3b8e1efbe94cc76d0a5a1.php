
<?php $__env->startSection('title','orderss'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($customer==0): ?>
<div class="alert alert-danger" role="alert">
  <h1 class="text-center"><?php echo e('No order yet'); ?></h1>  
</div>
<?php else: ?>

<div class="container ">
    <?php if(Session::has('cancel')): ?>
        <div class="alert alert-danger text-center" role="alert">
            <?php echo e(Session::get('cancel')); ?>

        </div>
        <?php endif; ?>
    <div class="table-responsive">


<table class="table table-bordered ">
 <thead>
    <?php
       $i=1;
    ?>
   <tr>
     <th scope="col">S/n</th>
     <th scope="col">Title</th>
     <th scope="col">Price</th>
     <th scope="col">Quantity</th>
     <th scope="col">Image</th>
     <th scope="col" class="text-center">Action</th>


   </tr>
 </thead>
 <tbody>
    <?php $__currentLoopData = $customer_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer_order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
   <tr>
     <th scope="row"><?php echo e($i++); ?></th>
     <td><?php echo e($customer_order->title); ?></td>
     <td>NGN <?php echo e(number_format($customer_order->price)); ?></td>
     <td><?php echo e(number_format($customer_order->quantity)); ?></td>

     <td><img  src="/product/<?php echo e($customer_order->image); ?>"  class="h-10 w-50 " alt="<?php echo e($customer_order->image); ?>" 
       height="50%" width="50%" style="height: 50px; width:50px">
     </td>
     <td class="text-center">
        <?php if($customer_order->delivery_status=='Processing'): ?>
        <div  href="<?php echo e(route('del',$customer_order->id)); ?>" class="btn btn-warning mb-4 my-md-4">Pending</div>
        <?php elseif($customer_order->delivery_status=='Delivered'): ?>
        <div href="<?php echo e(route('del',$customer_order->id)); ?>" class="btn btn-success mb-4 my-md-4">Delivered</div>
        <?php elseif($customer_order->delivery_status=='Rejected'): ?>
        <div href="<?php echo e(route('del',$customer_order->id)); ?>" class="btn btn-danger mb-4 my-md-4">Rejected</div>
        <?php else: ?>
        <div href="<?php echo e(route('del',$customer_order->id)); ?>" class="btn btn-primary mb-4 my-md-4">Shipping</div>
        <?php endif; ?>
        <?php if($customer_order->delivery_status=='Delivered'||$customer_order->delivery_status=='Rejected'): ?>
        <?php else: ?>
        <a href="<?php echo e(route('cancel',$customer_order->id)); ?>" class="btn btn-danger mb-4 my-md-4">Cancel</a>
        <?php endif; ?>

    </td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 </tbody>
</table>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopping_site\resources\views/customer_order.blade.php ENDPATH**/ ?>