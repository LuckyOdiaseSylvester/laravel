
<?php $__env->startSection('content'); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class=" content-wrapper">

            <?php if(Session::has('add')): ?>
              <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('add')); ?>

              </div>
              <?php endif; ?>
              <?php if(Session::has('delete')): ?>
              <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('delete')); ?>

              </div>
              <?php endif; ?>
            <h1 class="text-center">Add Category</h1>
            <form action="<?php echo e(route('add-cat')); ?> " method="POST">
              <?php echo csrf_field(); ?>
            <div class="input-group">
            <input id="pay" type="text" class="form-control <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder=" Add category..."
            name="category" 
           value="<?php echo e(old('category')); ?>" required autocomplete="category">
           <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
               <span class="invalid-feedback" role="alert">
                   <strong><?php echo e($message); ?></strong>
               </span>
           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <button class="btn btn-outline-secondary " type="submit">Add</button>
            </div>
          </form>
      
          <table class="table table-bordered">
            <tr>
              <th>Category Name</th>
              <th>Action </th>
            </tr>
           <?php $__currentLoopData = $adds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
            <tr>
              <td><?php echo e($add->category); ?></td>
              <td>
                <a onclick="return confirm('Are you sure you want to delete! this')" href="<?php echo e(route('delete',$add->id)); ?>" class="btn btn-danger">
                  Delete
                </a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </table>

          </div>
          <!-- content-wrapper ends -->
          <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopping_site\resources\views/add_category.blade.php ENDPATH**/ ?>